package noticeboard;

import java.io.Serializable;

public class User implements Serializable{

	String name;
	String id;
	String password;
	int userNum;

}
